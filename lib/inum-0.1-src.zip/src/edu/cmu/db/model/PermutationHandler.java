package edu.cmu.db.model;

/**
 * Created by IntelliJ IDEA.
 * User: Debabrata Dash
 * Date: Feb 25, 2006
 * Time: 12:22:10 AM
 * The file is a copyright of CMU, all rights reserved.
 */
public interface PermutationHandler {
    public void handle(Object []columns);
}
