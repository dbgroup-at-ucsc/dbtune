package edu.cmu.db.model;

import edu.cmu.db.Config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: Debabrata Dash
 * Date: May 16, 2006
 * Time: 1:19:28 PM
 * The file is a copyright of CMU, all rights reserved.
 */
public class ColumnHandler {
}
