package edu.cmu.db.autopilot;

/**
 * Created by IntelliJ IDEA.
 * User: Dash
 * Date: Dec 22, 2007
 * Time: 6:39:36 PM
 * To change this template use File | Settings | File Templates.
 */
public enum OpClass {
    INDEX_ACCESS,
    TABLE_ACCESS,
    JOIN;
}
