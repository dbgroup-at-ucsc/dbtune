package edu.cmu.db.mathprog;

import edu.cmu.db.model.Index;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: Dash
 * Date: Nov 6, 2008
 * Time: 9:23:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class Variables {
    List<Index> indexes = new ArrayList();
    List<String> queryCosts  = new ArrayList();
}
