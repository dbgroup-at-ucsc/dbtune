package edu.cmu.db.mathprog;

/**
 * Created by IntelliJ IDEA.
 * User: Dash
 * Date: Nov 6, 2008
 * Time: 6:07:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class GenerateSoftCostContraint {
}
