package edu.cmu.db.linprog;
import java.util.*;

import edu.cmu.db.model.QueryDesc;

public class LinQuery { 

    public int ID; 
    public int configCount;
    public QueryDesc QD;
    public int firstConfigID;
    public List configs;
}
