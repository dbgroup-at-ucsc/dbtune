package edu.cmu.db.linprog;

import edu.cmu.db.model.*;
import edu.cmu.db.inum.CostEstimator;
import edu.cmu.db.Config;
import edu.cmu.db.tools.Cloner;
import edu.cmu.db.autopilot.autopilot;

import java.util.*;
import java.io.File;

public class ConfigCosts {
    public static final boolean SAMPLE_CONFIGURATIONS = false;
    public static boolean limitCE = false;
    public static Set reallyInterestingTables = new HashSet();

    public static void main(String[] args) {

        try {
            //query workload
            String workloadFile = args[0];
            String outputPrefix   = args[1];
            String candidateFile = null;

            if (args.length > 2)
                candidateFile = args[2];

            List candidatePool = null;
            if (candidateFile != null)
                candidatePool = Configuration.loadFromFile(candidateFile);

            CostEstimator ce = new CostEstimator(workloadFile);
            WorkloadProcessor proc = ce.proc;
            autopilot ap = ce.AP;

            if (candidatePool == null)
                candidatePool = new ArrayList(proc.getCandidateIndexes());
            //dump candidates

            System.out.println("Used Memory: " + getUsedMemory());
            //for (ListIterator ci = candidatePool.listIterator(); ci.hasNext();) {
            //Configuration theCandidate = (Configuration) ci.next();
            //System.out.println("configcosts:" + theCandidate);
            //}

            //System.out.println("ConfigCosts: candidates: " + CE.CG.candidates + " size " + CE.CG.candidates.size());
            //System.out.println("configCosts: perQuery: " + CE.CG.candidatesPerQuery + " " + CE.CG.candidatesPerQuery.size());
            //System.exit(-1);

            ArrayList sizes = new ArrayList();
            for (ListIterator pi = candidatePool.listIterator(); pi.hasNext();) {
                Index idx = (Index) pi.next();
                sizes.add(ap.getIndexSize(idx));
            }
            List clusteredCandidates = new ArrayList();

/*
            if (Config.getDatabaseName().equals("tpch")) {
                // add the clustered candidates for lineitem
                clusteredCandidates = proc.getCandidateClusteredIndexes("lineitem");
                candidatePool.addAll(clusteredCandidates);
            }

            for (int i = 0; i < clusteredCandidates.size(); i++) {
                sizes.add(0.0f);
            }
*/

            ExtractConfigs EXC = new ExtractConfigs(new ArrayList(candidatePool));
            candidatePool = EXC.filteredConfigs;

            //Initialize a linear model and load the candidates ...
            LinearModel LM = new LinearModel();

            LM.addCandidates(new ArrayList(candidatePool), sizes);
            CPlexBuffer cbuf = new CPlexBuffer(outputPrefix);
            List []configCostArr = new List[proc.query_descriptors.size()];
            int index = 0;
            float totalCost = 0;

            for (ListIterator qi = proc.query_descriptors.listIterator(); qi.hasNext();) {
                QueryDesc QD = (QueryDesc) qi.next();

                configCostArr[index] = EXC.exhaustiveExtract(QD, ce, LM, cbuf);
                index ++;
                totalCost += QD.emptyCost;
            }

            System.out.println("totalCost = " + totalCost);

            for(int i=0;i<configCostArr.length;i++) {
                LM.addQueryConfigs(i, (QueryDesc) proc.query_descriptors.get(i), configCostArr[i], Float.MIN_VALUE, cbuf);
            }

            Set clusteredCandidateSet = new HashSet(clusteredCandidates);
            StringBuffer buf1 = new StringBuffer("clustered: ");
            boolean start = false;
            for (int i = 0; i < LM.candidateArray.length; i++) {
                LinCand cand = LM.candidateArray[i];
                if(cand.used > 0 && clusteredCandidateSet.contains(cand.index)) {
                    if(start) {
                        buf1.append(" + ");
                    }
                    buf1.append("y" + i);
                    start = true;
                }
            }
            buf1.append(" <= 1.0 ");
            cbuf.getCons().println(buf1);


            String buf = LM.getIndexSizeConstraint((float) 1 * 1024 * 1024 / 8);
            cbuf.getCons().print(buf);

            for (int i = 0; i < LM.candidateArray.length; i++) {
                LinCand cand = LM.candidateArray[i];
                StringBuffer buffer = new StringBuffer("y");
                if(cand.used > 0) {
                    buffer.append(i).append(" ").append("\\MODEL::").append(cand);
                    cbuf.getBin().println(buffer);
                }
            }

            cbuf.close();
        }
        catch (Exception E) {

            System.out.println("main: exception: " + E.getMessage());
            E.printStackTrace();
        }
    }

    private static void addToMap(String tableName, LinkedHashSet<String> columnNames, Map<String, Set<LinkedHashSet<String>>> indexes) {
        Set columnsets = indexes.get(tableName);
        if(columnsets == null) {
            columnsets = new HashSet();
            indexes.put(tableName, columnsets);
        }

        columnsets.add(columnNames);
    }

    public static long getUsedMemory() {
        System.gc();
        System.gc();
        System.gc();
        return Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    }
}
